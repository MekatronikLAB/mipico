from machine import Pin                                                                        
import time

buton = Pin(16, Pin.IN, Pin.PULL_DOWN) #miPICO üzerinde GP16 pinini, B1 pinine bağlayın.
led = Pin(17, Pin.OUT)  #miPICO üzerinde GP17 pinini, LED1 pinine bağlayın.

while True: 
     if buton.value():
          led.toggle()        
          time.sleep(0.3)
                                         
