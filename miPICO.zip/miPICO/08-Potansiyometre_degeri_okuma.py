
from machine import ADC           
import utime
pot = ADC(26)   #miPICO üzerinde GP26 pinini, POT pinine bağlayın.
while True: 
     print("Potansiyometre Değeri=", pot.read_u16()) 
     utime.sleep(0.2)