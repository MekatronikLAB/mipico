
from machine import Pin                                                                        
import utime
led_m = Pin(16, Pin.OUT)   #miPICO üzerinde GP16 pinini, BLUE pinine bağlayın.
led_k = Pin(17, Pin.OUT)   #miPICO üzerinde GP17 pinini, RED pinine bağlayın.
led_s = Pin(18, Pin.OUT)   #miPICO üzerinde GP18 pinini, YELLOW pinine bağlayın.
led_y = Pin(19, Pin.OUT)   #miPICO üzerinde GP19 pinini, GREEN pinine bağlayın.

led_k.value(0)                    #Tüm ışıkları söndürdük
led_s.value(0)                    
led_y.value(0)                   

LED_time = 0.12    # LED ler arası animasyon zamanı
#LED_tepkiZamani = 0.05   # LED lerin tepki süresi için kullanılabilir.

while True:        
    led_m.value(1)
    utime.sleep(LED_time)
    led_m.value(0)
    #utime.sleep(LED_tepkiZamani)
    
    led_k.value(1)
    utime.sleep(LED_time)
    led_k.value(0)
    #utime.sleep(LED_tepkiZamani)
    
    led_s.value(1)
    utime.sleep(LED_time)
    led_s.value(0)
    #utime.sleep(LED_tepkiZamani)
    
    led_y.value(1)
    utime.sleep(LED_time)
    led_y.value(0)
    #utime.sleep(LED_tepkiZamani)
    
   
    led_y.value(1)
    utime.sleep(LED_time)
    led_y.value(0)
    #utime.sleep(LED_tepkiZamani)
   
    led_s.value(1)
    utime.sleep(LED_time)
    led_s.value(0)
    
    led_k.value(1)
    utime.sleep(LED_time)
    led_k.value(0)
    #utime.sleep(LED_tepkiZamani)
    utime.sleep(LED_time)

    

    


                                         
