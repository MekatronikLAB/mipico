
from machine import Pin                                                                        
import utime

buton_1 = Pin(3, Pin.IN, Pin.PULL_DOWN)#miPICO üzerinde GP3 pinini, B1 pinine bağlayın.
buton_2 = Pin(4, Pin.IN, Pin.PULL_DOWN)#miPICO üzerinde GP4 pinini, B2 pinine bağlayın.
buton_3 = Pin(5, Pin.IN, Pin.PULL_DOWN)#miPICO üzerinde GP5 pinini, B3 pinine bağlayın.
led_m = Pin(16, Pin.OUT)   # mavi miPICO üzerinde GP16 pinini, LED1 pinine bağlayın.
led_k = Pin(17, Pin.OUT)   # kırmızı miPICO üzerinde GP17 pinini, LED2 pinine bağlayın.
led_s = Pin(18, Pin.OUT)   # sarı miPICO üzerinde GP18 pinini, LED3 pinine bağlayın.

while True:
    if buton_1.value() == 1:
        led_m.toggle()
        utime.sleep(0.2)
    if buton_2.value() == 1:
        led_k.toggle()
        utime.sleep(0.2)
    if buton_3.value() == 1:
        led_s.toggle()
        utime.sleep(0.2)
    


                                         
