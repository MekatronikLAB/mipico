#Onboard Sıcaklık#  
from machine import ADC, Pin, I2C
import utime


sicaklik_Pini = ADC(4)              
donusturme_carpani = 3.3 / (65535)

while True:
    okunan = sicaklik_Pini.read_u16() * donusturme_carpani
    sicaklik_Degeri = 27 - (okunan - 0.706)/0.001721
    print(sicaklik_Degeri)
    
    utime.sleep(1)


