from machine import Pin                                                                        
import utime

buton = Pin(16, Pin.IN, Pin.PULL_DOWN) #miPICO üzerinde GP16 pinini, B1 pinine bağlayın.
led = Pin(17, Pin.OUT)  #miPICO üzerinde GP17 pinini, LED1 pinine bağlayın.

while True: 
     if buton.value() == 1:
          led.value(1)        
          utime.sleep(2)
     led.value(0)                    
                                         
