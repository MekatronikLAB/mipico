
from machine import ADC, PWM, Pin   
import utime

pot = ADC(26)                  # miPICO üzerinde GP26-A0 pinini, POT pinine bağlayın.
led1 = PWM(Pin(16))             # miPICO üzerinde GP16 pinini, LED1 pinine bağlayın.
led1.freq(1000)               

while True: 
     print("LED'in Parlaklık Değeri=", pot.read_u16())
     led1.duty_u16(pot.read_u16()) 
 
     utime.sleep(0.2)        